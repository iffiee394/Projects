#include <cstdio>
#include <iostream>
#include <math.h>
#include <string>

using namespace std;

const int N = 4213;

void read_data(string *arr, FILE *input_file) {
    char ch;

    for (int i = 0; i < 8; i++) {
        string s = "";
        while ((ch = getc(input_file)) != '\t')
            s += ch == '\n' ? ' ' : ch;
        arr[i] = s;
    }

    string s = "";
    ch = getc(input_file);
    if (ch == '"') {
        while ((ch = getc(input_file)) != '"' && ch != EOF)
            s += ch == '\n' ? ' ' : ch;
        getc(input_file);
    } else {
        s += ch;
        while ((ch = getc(input_file)) != '\n' && ch != EOF)
            s += ch;
    }
    arr[8] = s;
}

bool isNumber(const string& s) //function to check for int values 
{
    for (char const &ch : s)
    {
        if (isdigit(ch) == 0)
        return false;
    }
    return true;
}

int stringtoint(string a) // Function to convert string to integer
{
    double z;
    int n=1;
    for (int i = 0; i < a.length(); i++)
    {
        int y=a[i]-48;
        z=z+y*pow(10,a.length()-n);
        n++;
    }
    return z;
}
// 1) counts number of times a person received the gifts and people who received most number of gifts
int count(string dataset[N][9])
{
    bool found;
    int index=0;
    string lineararr[N];
    for (int i = 0; i<N; i++)
    {
         found = false;
            for(int k = 0; k<N; k++)
            {
                if (lineararr[k]==dataset[i][2])
                {
                    found = true;
                }
            }
                if (!found)
                {
                    lineararr[index]=dataset[i][2];
                    index++;
                }
    }
    int cpt[index]={0};
    for(int k = 0; k<index; k++)
    {
        int counter = 0;
        for(int i = 0; i<N; i++)
        {
            if (lineararr[k]==dataset[i][2])
            {    
                counter ++;
            }
           // cout << lineararr[k] << ": " << counter << endl;    
        }
        cpt[k]=counter;
        
    }
    
    for(int i = 0; i<index; i++)
    {
        for(int j = i+1; j<index; j++)
        {
            if(cpt[j]>cpt[i])
            {
                int temp = cpt[j];
                cpt[j]=cpt[i];
                cpt[i]=temp;
                string temp1 = lineararr[j];
                lineararr[j]=lineararr[i];
                lineararr[i]=temp1;
            }
        }
    }
    for (int i=0; i<3; i++)
    {
        cout << cpt[i] << ":" <<lineararr[i] <<endl;
    }
}
// 2) names of the people who received most expensive gifts
void names(string dataset[N][9])
{
     bool found;
    int index=0;
    string lineararr[N];
    for (int i = 0; i<N; i++)
    {
            found = false;
            for(int k = 0; k<N; k++)
            {
                if (lineararr[k]==dataset[i][2])
                {
                    found = true;
                }
            }
                if (!found)
                {
                    lineararr[index]=dataset[i][2];
                    index++;
                }
    }

    int total[index];
    for(int i = 0; i<index; i++)
    {
        int singlemax = 0;
        for( int k = 0; k<N; k++)
        {
            if(lineararr[i]==dataset[k][2])
            {
                singlemax += stringtoint(dataset[k][5]);
                total[i]=singlemax;
            } 
        } 
    }
    for(int i = 0; i<index; i++)
    {
        for(int j = i+1; j<index; j++)
        {
            if(total[j]>total[i])
            {
                int temp = total[j];
                total[j]=total[i];
                total[i]=temp; 
                string temp1 = lineararr[j];
                lineararr[j]=lineararr[i];
                lineararr[i]=temp1;
            }
        }
    }

    cout << endl <<"Highest value of gifts :"<<endl;
        
        for(int i =0; i<3; i++)
        {  
            cout << lineararr[i] << " : " << total[i] << endl;
        }
}

// most expensive gifts' recipients
int maxval(string dataset[N][9])
{
    string lineararr[N];
    for(int i = 0; i<N; i++)
    {
        lineararr[i]=dataset[i][5];
    }
    int lineararr2[N]={0};
     
    for(int i = 0; i<N; i++)
    {
        lineararr2[i] = stringtoint(lineararr[i]);
    }
    for(int i = 0; i<N; i++)
    {
        for(int j = 1+i; j<N; j++)
        {
            if(lineararr2[j]>lineararr2[i])
            {
                int temp = lineararr2[j];
                lineararr2[j]=lineararr2[i];
                lineararr2[i]=temp;
            }
        }

    }
    cout << lineararr2[0];
}

// 3) total worth of the gifts
int total(string dataset[N][9])
{
    string lineararr[N];
    for(int i=0; i<N; i++)
    {
        lineararr[i]=dataset[i][5];
    }
    int lineararr2[N] = {0};
    for(int i=0; i<N; i++)
    {
        lineararr2[i] = stringtoint(lineararr[i]);
    }
    int worth = 0;
    for(int i = 0; i<N; i++)
    {
        worth += lineararr2[i];
    }
    return worth;   
}
// task 4

int retentioncost(string name,string dataset[][9],string namesonly[])
{   
        int total=0;
    for (int i = 0; i < N; i++)
    {   string check=namesonly[i];
        if (check==name)
        {
            int add=stringtoint(dataset[i][6]);
            total=total+add;            
        }     
    }
    return total;
}

//task5

void noretainedgift(string dataset[][9],string namesonly[])
{   
    int n=0;
    string recheck[N];
    for (int i = 1; i < N; i++)
    {   
        int answer=1;
        for (int j = 1; j< N; j++)
        {
            if (namesonly[i]==namesonly[j] && dataset[j][7]!="No")
            {
                answer=0;
            }            
        }
        if (answer==1)
        {
            recheck[n]=namesonly[i];
            n=n+1;
        } 
               
    }   
// To cout only unique elements in the array

     int j;
     int answer=0;
     int t=0;

    cout<<"The recepients who did not retain any gifts are: "<<endl;
    for (int i = 0; i <= n; i++)
    {             
        for ( j = i; j > t; j)
        {               
            if (recheck[j]==recheck[t])
            {
                answer=1;
            }
            t=t+1;
        }
        if (answer==0)
        {
            cout<<recheck[i]<<endl;
        }

        t=0;
        answer=0;
    }    
}

// task 6

    
    

    void noretentioncost(string dataset[][9], string namesonly[N])
    {   
        int flag=0;
        int d=0;
        string doublecheck[N];
        for (int i = 1; i < N; i++)
        {
            for (int j = 1; j < N; j++)
            {
                if (namesonly[i]==namesonly[j])
                {
                    
                    if (dataset[j][7]=="Yes")
                    {
                        flag=1;
                    } 
                }  
            }
            if (retentioncost(namesonly[i],dataset,namesonly)==0 && flag==1)
            {
                doublecheck[d]=namesonly[i];
                d=d+1;  
            }
                flag=0;
        }
        
        // To cout only unique elements of the array

        cout<<"The recepients who retained some gifts but paid no retention costs are: "<<endl;
        int j;
        for (int i = 0; i <= d; i++)
        {   
            int t=0; 
            int answer=0;         
            for ( j = i; j > t; t++)
            {               
                if (doublecheck[j]==doublecheck[t])
                {
                    answer=1;
                }
            }
            if (answer==0)
            {
                cout<<doublecheck[j]<<endl;
            }
        }          
    }

//  7. Find and return name of the most expensive gift received in Tosha Khana.

string find_max_7 (string arr[][9])
{
    int max_7 = stringtoint(arr[1][5]); // converts string entry to int
    int gift_7 = 0;
    string name_7 = "";


    for (int i=1; i<N; i++)
    {
        if (arr[i][5] != " " && arr[i][5] != "" && isNumber(arr[i][5]) == true ) // checks for consistent data for int datatype
        {
            int var = stringtoint(arr[i][5]); // converts entire string column to int
            if (var > max_7) // checking for max value 
            {
                max_7 = var;
                gift_7 = i;
                name_7 = arr[gift_7][0]; //name of gift with of max value 
            }
        }
    }
    return name_7; // return name of most expensive gift 
}

// 8.Find and return name of the most expensive gift received in Tosha Khana which was not retained by any recipient.

string find_max_8 (string arr[][9])
{
    int max = stringtoint(arr[1][5]);  // converts string entry to int
    int gift = 0;
    string name = "";

    for (int i=1; i<N; i++)
    {
        if (arr[i][5] != " " && arr[i][5] != "" && arr[i][7] == "No" && isNumber(arr[i][5]) == true ) //checks for consistent data for int datatype and retained gift = No  
        {
            int var = stringtoint(arr[i][5]);
            if (var > max) // checking for max value 
            {
                max = var;
                gift = i;
                name = arr[gift][0]; // name of most exp gift not retained
            }
        }
    }
    return name; // returns name of most exp gift not retained 
}
// 9. Find and print names of all gifts whose retention cost is more than a given limit. The limit should be passed as the argument to the function. 

void name_9(string arr[][9], int limit)
 {
    int count = 0;
    for (int i=1; i<N; i++)
    {
        if (arr[i][6] != " " && arr[i][6] != "" && isNumber(arr[i][6]) == true) // checks for consistent data for int datatype
        {
            int value = stringtoint(arr[i][6]); // converts entire string column to int
            
            if (value > limit)
            {
                cout << " " << arr[i][0] << endl; // prints all values greater than given limit 
                count++;
            }
        }
    }
    if (count == 0) // checks if dataset does not have value of given limit 
    {
        cout << "No item found for PKR " << limit << endl;
    }
 }

// Task 10, calculates % of gifts received by respective authorities 
 void task10 (string arr [][9])
 {
    float sum = 0;
    float avg = 0;
    string arr1[11]= {"Bureaucracy", "Gen Mus", "Gen Mush", "Judiciary", "Media", "Military", "MMA", "PMLN", "Police", "PPP", "PTI"};
    
    string x1 = "";
    cout << endl;
    cout << "\tPercentage of Gifts Received\t" << endl; 
    cout << endl;
    cout << "Affliation\t" << " \t " << "Percentage of Gifts (%)" << endl; 
    cout << endl;
    for (int j=0; j<11; j++)
    {
        int count = 0;
        
        for (int i=1; i<N; i++)
        {
            if ( arr[i][3] != " " && arr[i][3] != "")
            {
                if ( arr1[j]== arr[i][3])
                {
                    
                    x1 = arr[i][3];
                    count++;
                    avg = (count*1.0/N)*100;
                }
            }
        }
        if (x1.length() < 8)
            cout << x1 <<"\t\t"<< "| \t " << avg << endl;
        else 
            cout << x1 <<"\t"<< "| \t " << avg << endl;
        sum = avg + sum;
    }
     cout << endl;
     cout << "Sum: " <<  sum << "%" << endl;
    
    int space= 0;
    for (int i=1; i<N; i++)
        {
            if ( arr[i][3] != " " && arr[i][3] != "")
            space++;
        }
        cout << "Null: " << ((N-space*1.0)/N)*100 << "%" << endl; 

        cout << "Total: " << sum+((N-space*1.0)/N)*100 << "%" << endl; 
 }
int main() 
{
    FILE *input_file = fopen("projectdata.txt", "r");

    string dataset[N][9];
    for (int i = 0; i < N; i++)
    {
        read_data(dataset[i], input_file);
    }
    
        //task 1
        cout << endl;
        cout << "Recipients who have received the most number of gifts : " << endl;
        count(dataset);

         // task 3   
         cout << endl;
         cout << "Maximum value of a gift : ";
        maxval(dataset);

        // task 2      
        cout << endl;
        cout << endl <<"Total worth of gifts : " << total(dataset);
        names(dataset);

        //  array to store the names of the recepients ignoring their positions
    
        string namesonly[N];
        int t=0;
        for(int i=1; i<N; i++)
        {
             string recipient;
             for(int j=0; j<dataset[i][2].length(); j++)
             {
                 if(dataset[i][2].substr(j,1)!=",")
                 {
                     if (dataset[i][2].substr(j,1)=="\"")
                     {
                         j=j+1;
                     }
                    
                     recipient=recipient+dataset[i][2].substr(j,1);
                 }
                 else
                 {
                     break;
                 }
             }
             namesonly[i]=recipient;
             recipient="";
         }
        
        // Task 4
        string name;

        cout << endl;
        cout<<"Give the name of the recipient you want to know the retention cost of: "<<endl;
        getline(cin,name);
        cout<<"The total retention cost of "<<name<<"is "<<retentioncost(name,dataset,namesonly)<<endl;
        
        // task 5
        cout << endl;
        noretainedgift(dataset,namesonly);    
        
        // task 6
        cout << endl;
        noretentioncost(dataset,namesonly);
    
        // task 7
        cout << endl;
        string name_7 = find_max_7(dataset);
        cout << "Name of the most expensive gift received in Tosha Khana is " << name_7 << endl;
        
        // task 8
         cout << endl;
         string name_8 = find_max_8(dataset);
         cout << "Name of the most expensive gift received in Tosha Khana which was not retained by any recipient is " << name_8 << endl;

        // task 9
         cout << endl;
         int limit = 0;
         cout << "Enter the value to find names of all gifts whose retention cost is more than a given limit ";
         cin >> limit;
         name_9(dataset,limit);

        // task 10
        task10(dataset);
    
        return 0;
}

      



